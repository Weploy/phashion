#ifndef __GLIBC__
#include <sys/sysctl.h>
#endif
