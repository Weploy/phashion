package org.phash;
public class AudioHash extends Hash
{
	public int[] hash;	
}
